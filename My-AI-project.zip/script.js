// Create the button and add it to the page
const backToTopButton = document.createElement('button');
backToTopButton.textContent = '↑ Back to Top';
backToTopButton.id = 'back-to-top';
document.body.appendChild(backToTopButton);

// Style the button
const style = document.createElement('style');
style.textContent = `
    #back-to-top {
        position: fixed;
        bottom: 2rem;
        right: 2rem;
        padding: 0.75rem 1.25rem;
        background-color: #0047ab;
        color: white;
        border: none;
        border-radius: 50px;
        cursor: pointer;
        font-size: 1rem;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s, visibility 0.3s;
    }

    #back-to-top:hover {
        background-color: #003580;
    }

    #back-to-top.show {
        opacity: 1;
        visibility: visible;
    }
`;
document.head.appendChild(style);

// Add functionality to the button
window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        backToTopButton.classList.add('show');
    } else {
        backToTopButton.classList.remove('show');
    }
});

backToTopButton.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});
